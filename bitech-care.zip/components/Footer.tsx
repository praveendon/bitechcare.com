import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';
import { CONTACT_PHONE, CONTACT_EMAIL } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">BiTech Care</h3>
            <p className="text-gray-400 text-sm mb-4">
              Online-only certified refurbished laptops and trusted IT services. 
              Serving JP Nagar, Konanakunte, and South Bangalore.
            </p>
            <p className="text-xs text-yellow-400 font-semibold border border-yellow-400 p-2 inline-block rounded">
              ONLINE BUSINESS ONLY
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>Refurbished Laptop Sales</li>
              <li>Laptop Repair & Upgrades</li>
              <li>Data Recovery</li>
              <li>Bulk Corporate Supply</li>
              <li>Doorstep Service (Confirmed)</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li className="flex items-center">
                <Phone size={16} className="mr-2 text-secondary" />
                <a href={`tel:${CONTACT_PHONE}`}>{CONTACT_PHONE}</a>
              </li>
              <li className="flex items-center">
                <Mail size={16} className="mr-2 text-secondary" />
                <a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>
              </li>
              <li className="flex items-start">
                <MapPin size={16} className="mr-2 text-secondary mt-1" />
                <span>
                  South Bangalore Operations<br/>
                  <span className="text-xs italic">(No Walk-in Store Available)</span>
                </span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-xs text-gray-500">
          <p>&copy; {new Date().getFullYear()} BiTech Care. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;