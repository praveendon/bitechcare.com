import React from 'react';
import { MessageCircle } from 'lucide-react';
import { WHATSAPP_LINK } from '../constants';

const FloatingWhatsApp: React.FC = () => {
  const defaultMessage = "?text=Hello%20BiTech%20Care,%20I%20need%20assistance.";
  
  return (
    <a
      href={`${WHATSAPP_LINK}${defaultMessage}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg z-50 transition-all duration-300 hover:scale-110 flex items-center justify-center animate-bounce"
      aria-label="Contact on WhatsApp"
    >
      <MessageCircle size={32} fill="white" />
    </a>
  );
};

export default FloatingWhatsApp;