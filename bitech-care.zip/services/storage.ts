import { Enquiry } from '../types';

const STORAGE_KEY = 'bitech_enquiries';

export const getEnquiries = (): Enquiry[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveEnquiry = (enquiry: Enquiry): void => {
  const current = getEnquiries();
  const updated = [enquiry, ...current];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
};

export const clearEnquiries = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};