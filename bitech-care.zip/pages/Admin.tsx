import React, { useState, useEffect } from 'react';
import { getEnquiries, clearEnquiries } from '../services/storage';
import { Enquiry } from '../types';
import { Lock, Trash2, Phone, Mail } from 'lucide-react';

const Admin: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);

  // Simple hardcoded auth for demo purposes
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin123') {
      setIsAuthenticated(true);
      setEnquiries(getEnquiries());
    } else {
      alert('Invalid Password');
    }
  };

  const handleRefresh = () => {
    setEnquiries(getEnquiries());
  };

  const handleClear = () => {
    if(window.confirm("Are you sure you want to delete all enquiries?")) {
      clearEnquiries();
      setEnquiries([]);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <form onSubmit={handleLogin} className="bg-white p-8 rounded-lg shadow-md w-80">
          <div className="flex justify-center mb-4">
            <div className="bg-blue-100 p-3 rounded-full">
              <Lock className="w-6 h-6 text-primary" />
            </div>
          </div>
          <h2 className="text-xl font-bold text-center mb-4">Admin Login</h2>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter Password (admin123)"
            className="w-full border border-gray-300 rounded px-3 py-2 mb-4 focus:outline-none focus:border-blue-500"
          />
          <button type="submit" className="w-full bg-primary text-white py-2 rounded hover:bg-blue-700">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4 sm:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-gray-800">Admin Dashboard - Enquiries</h1>
          <div className="space-x-2">
            <button onClick={handleRefresh} className="bg-blue-500 text-white px-4 py-2 rounded text-sm hover:bg-blue-600">Refresh Data</button>
            <button onClick={handleClear} className="bg-red-500 text-white px-4 py-2 rounded text-sm hover:bg-red-600 flex items-center inline-flex">
              <Trash2 className="w-4 h-4 mr-1" /> Clear All
            </button>
          </div>
        </div>

        {enquiries.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
            No enquiries found. Submit a request via the form to see it here.
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Issue</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {enquiries.map((enq) => (
                    <tr key={enq.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{enq.date}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{enq.name}</div>
                        <div className="text-sm text-gray-500">{enq.location}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center text-sm text-gray-500">
                          <Phone className="w-4 h-4 mr-1" /> {enq.mobile}
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Mail className="w-4 h-4 mr-1" /> {enq.email}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {enq.issueType}
                        </span>
                        <div className="text-xs text-gray-500 mt-1">{enq.laptopBrand}</div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate" title={enq.description}>
                        {enq.description}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;