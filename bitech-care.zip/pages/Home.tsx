import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, Truck, Package, HeadphonesIcon } from 'lucide-react';
import { WHATSAPP_LINK } from '../constants';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-900 to-blue-800 text-white py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
            Certified Refurbished Laptops & <br className="hidden md:block"/> Trusted Services
          </h1>
          <p className="text-xl md:text-2xl text-blue-100 mb-8 font-light">
            Technology with Care
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link 
              to="/products" 
              className="bg-white text-blue-900 font-bold py-3 px-8 rounded-full hover:bg-gray-100 transition duration-300 shadow-lg"
            >
              View Laptops
            </Link>
            <a 
              href={`${WHATSAPP_LINK}?text=Hello%20BiTech%20Care,%20I%20want%20to%20know%20more.`}
              target="_blank"
              rel="noreferrer"
              className="bg-green-500 text-white font-bold py-3 px-8 rounded-full hover:bg-green-600 transition duration-300 shadow-lg flex items-center justify-center gap-2"
            >
              WhatsApp Enquiry
            </a>
            <Link 
              to="/request" 
              className="bg-transparent border-2 border-white text-white font-bold py-3 px-8 rounded-full hover:bg-white/10 transition duration-300"
            >
              Request Service
            </Link>
          </div>
        </div>
      </div>

      {/* Highlights Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800">Why Choose BiTech Care?</h2>
            <p className="text-gray-600 mt-2">Reliable tech solutions delivered to your doorstep.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-md text-center hover:-translate-y-1 transition duration-300">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="text-primary w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg mb-2">Ready Stock</h3>
              <p className="text-gray-600 text-sm">Wide range of business series laptops available immediately.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md text-center hover:-translate-y-1 transition duration-300">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="text-primary w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg mb-2">6 Months Warranty</h3>
              <p className="text-gray-600 text-sm">Service warranty on all refurbished laptops for peace of mind.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md text-center hover:-translate-y-1 transition duration-300">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="text-primary w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg mb-2">Doorstep Service</h3>
              <p className="text-gray-600 text-sm">We come to you. Service pickup and drop available in South Bangalore.</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md text-center hover:-translate-y-1 transition duration-300">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <HeadphonesIcon className="text-primary w-8 h-8" />
              </div>
              <h3 className="font-bold text-lg mb-2">Online Support</h3>
              <p className="text-gray-600 text-sm">Instant support via WhatsApp for bulk orders and corporate requirements.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Online Only Notice */}
      <div className="bg-yellow-50 border-y border-yellow-200 py-8 text-center px-4">
        <p className="text-yellow-800 font-medium">
          <span className="font-bold">NOTE:</span> We operate as an <span className="underline">ONLINE-ONLY</span> business. Please contact us via WhatsApp for all enquiries. No walk-in store available.
        </p>
      </div>
    </div>
  );
};

export default Home;