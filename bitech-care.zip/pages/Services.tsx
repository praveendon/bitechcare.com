import React from 'react';
import { SERVICES_LIST, WHATSAPP_LINK } from '../constants';
import * as Icons from 'lucide-react';

const Services: React.FC = () => {
  // Helper to dynamically render icons
  const renderIcon = (iconName: string) => {
    const IconComponent = (Icons as any)[iconName];
    return IconComponent ? <IconComponent className="w-10 h-10 text-primary" /> : <Icons.HelpCircle className="w-10 h-10 text-primary" />;
  };

  return (
    <div className="bg-white min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-extrabold text-gray-900">Our Services</h1>
          <p className="mt-4 text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive IT solutions for individuals and businesses. 
            We provide doorstep pickup and drop services across South Bangalore.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES_LIST.map((service) => (
            <div key={service.id} className="border border-gray-100 bg-gray-50 rounded-xl p-8 hover:bg-white hover:shadow-xl hover:border-blue-100 transition-all duration-300">
              <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center shadow-sm mb-6">
                {renderIcon(service.icon)}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <a 
                href={`${WHATSAPP_LINK}?text=I%20am%20interested%20in%20your%20service:%20${encodeURIComponent(service.title)}`}
                target="_blank"
                rel="noreferrer"
                className="text-primary font-semibold hover:text-blue-800 flex items-center"
              >
                Enquire Now <Icons.ArrowRight className="w-4 h-4 ml-1" />
              </a>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-blue-900 rounded-2xl p-8 md:p-12 text-center text-white">
          <h2 className="text-2xl font-bold mb-4">Need a Custom Solution?</h2>
          <p className="mb-8 text-blue-100">
            We offer Annual Maintenance Contracts (AMC) for offices and bulk laptop supplies.
          </p>
          <a 
            href={`${WHATSAPP_LINK}?text=Hello,%20I%20have%20a%20corporate/bulk%20enquiry.`}
            target="_blank"
            rel="noreferrer"
            className="inline-block bg-white text-blue-900 font-bold py-3 px-8 rounded-full hover:bg-gray-100 transition duration-300"
          >
            Contact for Corporate Deals
          </a>
        </div>
      </div>
    </div>
  );
};

export default Services;