import React from 'react';
import { Phone, Mail, MapPin, MessageCircle, AlertOctagon } from 'lucide-react';
import { CONTACT_PHONE, CONTACT_EMAIL, WHATSAPP_LINK } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="bg-gray-50 min-h-screen py-12 px-4">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
        
        {/* CRITICAL WARNING BANNER */}
        <div className="bg-yellow-100 border-l-4 border-yellow-500 p-6 flex flex-col md:flex-row items-center justify-center text-center md:text-left gap-4">
          <AlertOctagon className="w-12 h-12 text-yellow-600 flex-shrink-0" />
          <div>
            <h2 className="text-xl font-bold text-yellow-800 uppercase tracking-wide">Online-Only Business</h2>
            <p className="text-yellow-700 mt-1">
              BiTech Care does <strong>NOT</strong> have a physical walk-in store. 
              Please contact us via Phone or WhatsApp. Do not visit any location without prior appointment/confirmation.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          <div className="p-8 md:p-12 space-y-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Get in Touch</h1>
              <p className="text-gray-600 mt-2">We are just a message away.</p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Phone</h3>
                  <p className="text-gray-600 mb-1">Mon-Sat, 10am - 7pm</p>
                  <a href={`tel:${CONTACT_PHONE}`} className="text-xl font-bold text-primary hover:underline">{CONTACT_PHONE}</a>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-green-100 p-3 rounded-full mr-4">
                  <MessageCircle className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">WhatsApp</h3>
                  <p className="text-gray-600 mb-1">Fastest response time</p>
                  <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="text-xl font-bold text-green-600 hover:underline">Chat Now</a>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Email</h3>
                  <a href={`mailto:${CONTACT_EMAIL}`} className="text-gray-600 hover:text-primary">{CONTACT_EMAIL}</a>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 p-8 md:p-12 text-white">
            <h3 className="text-2xl font-bold mb-6">Service Coverage</h3>
            <p className="mb-6 text-gray-300">
              We provide doorstep pickup and drop services for confirmed orders and repairs in the following areas:
            </p>
            
            <ul className="space-y-4 mb-8">
              <li className="flex items-center">
                <MapPin className="w-5 h-5 mr-3 text-blue-400" /> JP Nagar (All Phases)
              </li>
              <li className="flex items-center">
                <MapPin className="w-5 h-5 mr-3 text-blue-400" /> Konanakunte
              </li>
              <li className="flex items-center">
                <MapPin className="w-5 h-5 mr-3 text-blue-400" /> Jayanagar
              </li>
              <li className="flex items-center">
                <MapPin className="w-5 h-5 mr-3 text-blue-400" /> Bannerghatta Road
              </li>
              <li className="flex items-center">
                <MapPin className="w-5 h-5 mr-3 text-blue-400" /> BTM Layout
              </li>
            </ul>

            <div className="border-t border-gray-600 pt-6 mt-6">
              <p className="text-sm text-gray-400 italic">
                *Doorstep charges may apply based on exact location and order value.
              </p>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Contact;