import React from 'react';
import { Shield, XCircle, AlertTriangle } from 'lucide-react';

const Warranty: React.FC = () => {
  return (
    <div className="bg-white min-h-screen py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-extrabold text-gray-900 mb-8 border-b pb-4">Warranty Policy & Terms</h1>

        <div className="space-y-8">
          
          <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-600">
            <h2 className="flex items-center text-xl font-bold text-gray-800 mb-4">
              <Shield className="w-6 h-6 mr-2 text-blue-600" />
              6 Months Service Warranty
            </h2>
            <p className="text-gray-700">
              All certified refurbished laptops sold by BiTech Care come with a 6-month limited service warranty. 
              This covers internal hardware malfunctions that occur during normal usage conditions.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="border border-green-200 rounded-lg p-6">
              <h3 className="font-bold text-lg text-green-700 mb-4">What is Covered</h3>
              <ul className="list-disc list-inside space-y-2 text-gray-600 text-sm">
                <li>Motherboard component failures.</li>
                <li>Hard Drive / SSD failures (Hardware only, not data).</li>
                <li>RAM defects.</li>
                <li>Original Adapter provided with the laptop.</li>
                <li>OS boot issues (if OS provided by us).</li>
              </ul>
            </div>

            <div className="border border-red-200 rounded-lg p-6">
              <h3 className="font-bold text-lg text-red-700 mb-4 flex items-center">
                 <XCircle className="w-5 h-5 mr-2" />
                 What is NOT Covered
              </h3>
              <ul className="list-disc list-inside space-y-2 text-gray-600 text-sm">
                <li>Physical damage (Drops, cracks, dents).</li>
                <li>Liquid damage (Water/Coffee spills).</li>
                <li>Burnt components due to voltage surge.</li>
                <li>Screen lines or cracks appearing after delivery.</li>
                <li>Battery backup (as it is a consumable part).</li>
                <li>Software issues caused by user installation.</li>
              </ul>
            </div>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-bold text-lg text-gray-800 mb-4 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-yellow-600" />
              Important Terms
            </h3>
            <ul className="space-y-3 text-gray-600 text-sm">
              <li><strong>Data Safety:</strong> We are not responsible for any data loss during repair or warranty claims. Please backup your data regularly. Data recovery is a separate, chargeable service.</li>
              <li><strong>No Refund Policy:</strong> Goods once sold will not be taken back or exchanged for cash.</li>
              <li><strong>Seal Tampering:</strong> Warranty is void if the laptop is opened or repaired by a third-party technician.</li>
              <li><strong>Service Mode:</strong> Warranty services are carry-in (or doorstep pickup chargeable basis) depending on location.</li>
            </ul>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Warranty;