import React, { useState, useMemo } from 'react';
import { MOCK_LAPTOPS, WHATSAPP_LINK } from '../constants';
import { MessageCircle, CheckCircle, Search, Filter } from 'lucide-react';

const OptimizedImage: React.FC<{ src: string; alt: string }> = ({ src, alt }) => {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className="w-full h-full relative bg-gray-200 overflow-hidden">
      <div 
        className={`absolute inset-0 bg-gray-300 animate-pulse transition-opacity duration-500 ${
          isLoaded ? 'opacity-0' : 'opacity-100'
        }`} 
      />
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        className={`w-full h-full object-cover transition-opacity duration-500 ease-in-out ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        onLoad={() => setIsLoaded(true)}
      />
    </div>
  );
};

const Products: React.FC = () => {
  const [filterBrand, setFilterBrand] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const brands = useMemo(() => {
    const b = Array.from(new Set(MOCK_LAPTOPS.map(l => l.brand)));
    return ['All', ...b.sort()];
  }, []);

  const filteredLaptops = useMemo(() => {
    return MOCK_LAPTOPS.filter(laptop => {
      const matchesBrand = filterBrand === 'All' || laptop.brand === filterBrand;
      const matchesSearch = laptop.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           laptop.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           laptop.processor.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesBrand && matchesSearch;
    });
  }, [filterBrand, searchTerm]);

  return (
    <div className="bg-gray-50 min-h-screen py-8 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Certified Refurbished Laptops</h1>
          <p className="mt-4 text-xl text-gray-500">Premium business performance, responsibly refurbished.</p>
          <div className="mt-4 inline-flex items-center px-4 py-2 rounded-full bg-blue-100 text-blue-800 text-sm font-medium">
            <CheckCircle className="w-4 h-4 mr-2" />
            6 Months Service Warranty Included
          </div>
        </div>

        {/* Filters and Search */}
        <div className="mb-10 space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Brand Filter */}
            <div className="flex flex-wrap justify-center gap-2 overflow-x-auto pb-2 w-full md:w-auto">
              {brands.map(brand => (
                <button
                  key={brand}
                  onClick={() => setFilterBrand(brand)}
                  className={`px-4 py-2 rounded-full text-sm font-semibold transition-all duration-200 border ${
                    filterBrand === brand 
                      ? 'bg-primary text-white border-primary shadow-md' 
                      : 'bg-white text-gray-600 border-gray-200 hover:border-primary hover:text-primary'
                  }`}
                >
                  {brand}
                </button>
              ))}
            </div>

            {/* Search Bar */}
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search models, brands..." 
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="text-sm text-gray-500 text-center md:text-left">
            Showing {filteredLaptops.length} {filteredLaptops.length === 1 ? 'laptop' : 'laptops'}
          </div>
        </div>

        {/* Product Grid */}
        {filteredLaptops.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredLaptops.map((laptop) => (
              <div key={laptop.id} className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col transition-all duration-300 hover:shadow-2xl hover:translate-y-[-4px] border border-gray-100">
                <div className="h-52 bg-gray-200 relative">
                  <OptimizedImage 
                    src={laptop.imageUrl} 
                    alt={laptop.name} 
                  />
                  <div className="absolute top-3 right-3 bg-primary text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-sm z-10">
                    CERTIFIED REFURBISHED
                  </div>
                  { (laptop.storage.includes('1TB') || laptop.storage.includes('2TB')) && (
                    <div className="absolute top-3 left-3 bg-orange-500 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-sm z-10">
                      HIGH STORAGE
                    </div>
                  )}
                </div>
                
                <div className="p-6 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                      <div className="flex-1 pr-2">
                        <span className="block text-xs font-bold text-blue-600 uppercase tracking-wider mb-1">{laptop.brand}</span>
                        <h3 className="text-xl font-bold text-gray-900 leading-tight">{laptop.name}</h3>
                      </div>
                      <div className="bg-green-50 text-green-700 text-[10px] font-bold px-2 py-1 rounded">IN STOCK</div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-y-3 gap-x-2 text-sm text-gray-600 mb-6 bg-gray-50 p-4 rounded-lg">
                    <div>
                      <p className="text-[10px] uppercase text-gray-400 font-bold mb-0.5">Processor</p>
                      <p className="font-medium line-clamp-1">{laptop.processor}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-gray-400 font-bold mb-0.5">RAM</p>
                      <p className="font-medium">{laptop.ram}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-gray-400 font-bold mb-0.5">Storage</p>
                      <p className="font-medium text-blue-700">{laptop.storage}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-gray-400 font-bold mb-0.5">Display</p>
                      <p className="font-medium">{laptop.screen}</p>
                    </div>
                  </div>

                  <div className="mt-auto">
                    <div className="flex items-baseline justify-between mb-4">
                      <div>
                        <span className="text-3xl font-extrabold text-primary">₹{laptop.price.toLocaleString()}</span>
                        <span className="text-xs text-gray-400 ml-1 line-through">₹{(laptop.price * 1.4).toLocaleString()}</span>
                      </div>
                      <span className="text-[10px] text-gray-500 font-medium italic">6 mo warranty</span>
                    </div>
                    
                    <a 
                      href={`${WHATSAPP_LINK}?text=Hi%20BiTech%20Care,%20I%20am%20interested%20in%20the%20${encodeURIComponent(laptop.name)}%20(${laptop.brand})%20priced%20at%20₹${laptop.price.toLocaleString()}.%20Is%20it%20available?`}
                      target="_blank"
                      rel="noreferrer"
                      className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3.5 px-4 rounded-xl flex items-center justify-center transition-all duration-300 shadow-md hover:shadow-lg active:scale-95"
                    >
                      <MessageCircle className="w-5 h-5 mr-2" />
                      Inquire on WhatsApp
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-2xl shadow-sm border border-dashed border-gray-300">
            <Filter className="mx-auto h-12 w-12 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No laptops found</h3>
            <p className="text-gray-500 mt-2">Try adjusting your filters or search term to find what you're looking for.</p>
            <button 
              onClick={() => { setFilterBrand('All'); setSearchTerm(''); }}
              className="mt-4 text-primary font-bold hover:underline"
            >
              Clear all filters
            </button>
          </div>
        )}

        {/* Corporate Notice */}
        <div className="mt-16 bg-blue-50 border border-blue-100 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-lg font-bold text-blue-900">Bulk / Corporate Enquiries</h3>
            <p className="text-blue-700 text-sm">Need 5+ laptops for your team? We offer special pricing for corporate clients.</p>
          </div>
          <a 
            href={`${WHATSAPP_LINK}?text=Hello%20BiTech%20Care,%20I%20have%20a%20bulk%20requirement%20for%20my%20office.`}
            target="_blank"
            rel="noreferrer"
            className="whitespace-nowrap bg-blue-900 text-white px-6 py-3 rounded-lg font-bold hover:bg-blue-800 transition-colors"
          >
            Get Bulk Quote
          </a>
        </div>
      </div>
    </div>
  );
};

export default Products;